(function() {
    const allProducts = [
        { id: 1, name: "Архитектурный фонтан из бетона", shortName: "Фонтан", price: 67900, category: "fountain", image: "fontan.jpg", isHit: true, description: "Элегантный фонтан из арт-бетона станет украшением любого сада или парка. Морозостойкий, не боится перепадов температур. Ручная работа, уникальная текстура. Размер любой по запросу" },
        { id: 2, name: "Эмитация дерева из бетона", shortName: "Дерево", price: 138500, category: "tree", image: "derevo.jpg", isHit: true, description: "Скульптурная композиция, имитирующая дерево. Ручная работа, уникальная текстура коры. Размер любой по запросу Идеально подходит для ландшафтного дизайна." },
        { id: 3, name: "Лавка из арт-бетона", shortName: "Лавка", price: 28700, category: "bench", image: "lavka.jpg", isHit: false, description: "Уличная лавка с деревянными вставками. Выдерживает любые погодные условия. Антивандальное покрытие. Размер любой по запросу." },
        { id: 4, name: "Арки из арт-бетона", shortName: "Арка", price: 45200, category: "arch", image: "arka.jpg", isHit: false, description: "Декоративная арка для сада или парка. Можно использовать как элемент зонирования или фотозону. Размер любой по запросу" },
    ];

    function renderProducts(containerId, productsToRender, columns = 'repeat(auto-fit, minmax(270px, 1fr)') {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.style.gridTemplateColumns = columns;
        container.innerHTML = '';
        
        productsToRender.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.innerHTML = `
                <div class="product-img" style="background-image: linear-gradient(0deg, rgba(0,0,0,0.3), rgba(0,0,0,0.2)), url('img/${product.image}'); background-size: cover; background-position: center;">
                    <span>${product.shortName}</span>
                </div>
                <div class="card-info">
                    <h3>${product.name}</h3>
                    <div class="price">${product.price.toLocaleString()} ₽</div>
                    <div style="display: flex; gap: 10px;">
                        <a href="#" class="btn btn-card" data-id="${product.id}" data-container="${containerId}">Подробнее</a>
                        <button class="btn btn-card add-to-cart-btn" data-id="${product.id}">В корзину</button>
                    </div>
                </div>
            `;
            container.appendChild(card);
        });
    }

    const CART_KEY = 'marya_cart';

    function getCart() {
        const cart = localStorage.getItem(CART_KEY);
        return cart ? JSON.parse(cart) : [];
    }

    function saveCart(cart) {
        localStorage.setItem(CART_KEY, JSON.stringify(cart));
        updateCartUI();
    }

    function addToCart(productId) {
        const cart = getCart();
        const existingItem = cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ id: productId, quantity: 1 });
        }
        
        saveCart(cart);
        showNotification('Товар добавлен в корзину');
    }

    function removeFromCart(productId) {
        let cart = getCart();
        cart = cart.filter(item => item.id !== productId);
        saveCart(cart);
        showNotification('Товар удалён из корзины');
    }

    function getCartWithDetails() {
        const cart = getCart();
        return cart.map(item => {
            const product = allProducts.find(p => p.id === item.id);
            return {
                ...item,
                name: product ? product.name : 'Товар не найден',
                price: product ? product.price : 0,
                image: product ? product.image : '',
                shortName: product ? product.shortName : ''
            };
        });
    }

    function updateCartUI() {
        const cart = getCart();
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        const cartCountSpan = document.getElementById('cart-count');
        if (cartCountSpan) {
            cartCountSpan.textContent = totalItems;
        }
        
        const cartItemsContainer = document.getElementById('cart-items');
        const cartTotalSpan = document.getElementById('cart-total');
        
        if (!cartItemsContainer) return;
        
        const cartWithDetails = getCartWithDetails();
        
        if (cartWithDetails.length === 0) {
            cartItemsContainer.innerHTML = '<p class="cart-empty">Корзина пуста</p>';
            if (cartTotalSpan) cartTotalSpan.textContent = '0';
            return;
        }
        
        let total = 0;
        cartItemsContainer.innerHTML = '';
        
        cartWithDetails.forEach(item => {
            const itemTotal = item.price * item.quantity;
            total += itemTotal;
            
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.innerHTML = `
                <div class="cart-item-img" style="background-image: url('img/${item.image}')"></div>
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">${item.price.toLocaleString()} ₽ × ${item.quantity}</div>
                </div>
                <button class="cart-item-remove" data-id="${item.id}">
                    <i class="fas fa-trash-alt"></i>
                </button>
            `;
            cartItemsContainer.appendChild(itemElement);
        });
        
        if (cartTotalSpan) {
            cartTotalSpan.textContent = total.toLocaleString();
        }
        
        document.querySelectorAll('.cart-item-remove').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(btn.getAttribute('data-id'));
                removeFromCart(id);
            });
        });
    }

    function showNotification(message) {
        let notification = document.querySelector('.cart-notification');
        if (notification) {
            notification.remove();
        }
        
        notification = document.createElement('div');
        notification.className = 'cart-notification';
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 2000);
    }

    function toggleCart() {
        const sidebar = document.getElementById('cartSidebar');
        const overlay = document.getElementById('cartOverlay');
        sidebar.classList.toggle('open');
        if (overlay) overlay.classList.toggle('show');
    }

    function initCart() {
        updateCartUI();
        
        const cartIcon = document.querySelector('.cart-icon');
        if (cartIcon) {
            cartIcon.addEventListener('click', toggleCart);
        }
        
        const cartClose = document.querySelector('.cart-close');
        if (cartClose) {
            cartClose.addEventListener('click', toggleCart);
        }
        
        let overlay = document.getElementById('cartOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'cartOverlay';
            overlay.className = 'overlay';
            document.body.appendChild(overlay);
            overlay.addEventListener('click', toggleCart);
        }
        
        const checkoutBtn = document.getElementById('checkout-btn');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', () => {
                const cart = getCart();
                if (cart.length === 0) {
                    showNotification('Корзина пуста');
                    return;
                }
                showNotification('Переход к оформлению заказа...');
                setTimeout(() => {
                    toggleCart();
                    switchPage('contacts');
                    history.pushState(null, '', '#contacts');
                }, 500);
            });
        }
    }

    function openProductModal(productId) {
        const product = allProducts.find(p => p.id === productId);
        if (!product) return;
        
        const modal = document.getElementById('productModal');
        const modalImg = document.getElementById('modal-product-img');
        const modalName = document.getElementById('modal-product-name');
        const modalPrice = document.getElementById('modal-product-price');
        const modalDescription = document.getElementById('modal-product-description');
        
        modalImg.style.backgroundImage = `linear-gradient(0deg, rgba(0,0,0,0.3), rgba(0,0,0,0.2)), url('img/${product.image}')`;
        modalName.textContent = product.name;
        modalPrice.textContent = `${product.price.toLocaleString()} ₽`;
        modalDescription.textContent = product.description;
        
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
    
    function closeProductModal() {
        const modal = document.getElementById('productModal');
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }

    const hitProducts = allProducts.filter(p => p.isHit === true);
    renderProducts('hits-container', hitProducts, 'repeat(2, 1fr)');
    renderProducts('catalog-container', allProducts);

    document.addEventListener('click', function(e) {
        const target = e.target;
        if (target.classList && target.classList.contains('btn-card') && !target.classList.contains('add-to-cart-btn')) {
            e.preventDefault();
            const containerId = target.getAttribute('data-container');
            const productId = parseInt(target.getAttribute('data-id'));
            openProductModal(productId);
        }
        
        if (target.classList && target.classList.contains('add-to-cart-btn')) {
            e.preventDefault();
            const productId = parseInt(target.getAttribute('data-id'));
            addToCart(productId);
        }
    });
    
    const modal = document.getElementById('productModal');
    const closeBtn = document.querySelector('.modal-close');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', closeProductModal);
    }
    
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeProductModal();
            }
        });
    }
    
    const orderBtn = document.getElementById('modal-order-btn');
    if (orderBtn) {
        orderBtn.addEventListener('click', function() {
            closeProductModal();
            switchPage('contacts');
            history.pushState(null, '', '#contacts');
        });
    }

    window.addEventListener('load', function() {
        const loader = document.getElementById('loader');
        if (loader) {
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.style.display = 'none';
            }, 350);
        }
        document.body.classList.add('page-loaded');
        
        addMap();
        setupSocialButtons();
        initCart();
    });

    function addMap() {
        const mapPlaceholder = document.querySelector('.map-placeholder');
        if (mapPlaceholder && !mapPlaceholder.querySelector('iframe')) {
            mapPlaceholder.innerHTML = '';
            mapPlaceholder.style.padding = '0';
            mapPlaceholder.style.border = 'none';
            
            const iframe = document.createElement('iframe');
            iframe.src = 'https://yandex.ru/map-widget/v1/?um=constructor%3A1a2b3c4d5e6f7g8h9i0j&source=constructor';
            iframe.width = '100%';
            iframe.height = '100%';
            iframe.style.border = '0';
            iframe.style.borderRadius = '8px';
            iframe.allowFullscreen = true;
            mapPlaceholder.appendChild(iframe);
        }
    }

    function setupSocialButtons() {
        const whatsappBtn = document.querySelector('.btn-wa');
        if (whatsappBtn) {
            whatsappBtn.addEventListener('click', function(e) {
                e.preventDefault();
                window.open('https://wa.me/79645053788?text=Здравствуйте!', '_blank');
            });
        }
        
        const telegramBtn = document.querySelector('.btn-tg');
        if (telegramBtn) {
            telegramBtn.addEventListener('click', function(e) {
                e.preventDefault();
                window.open('https://t.me/kinderbeton', '_blank');
            });
        }
    }

    const navLinks = document.querySelectorAll('.nav-link[data-page]');
    const pages = document.querySelectorAll('.page');

    function switchPage(pageId) {
        pages.forEach(p => p.classList.remove('active-page'));
        const activePage = document.getElementById(pageId);
        if (activePage) activePage.classList.add('active-page');

        navLinks.forEach(link => {
            const linkPage = link.getAttribute('data-page');
            if (linkPage === pageId) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });

        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        if (pageId === 'contacts') {
            setTimeout(addMap, 100);
        }
    }

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const pageId = this.getAttribute('data-page');
            if (pageId) {
                switchPage(pageId);
                history.pushState(null, '', '#' + pageId);
            }
        });
    });

    function handleHash() {
        const hash = window.location.hash.substring(1);
        if (hash && ['home', 'catalog', 'about', 'contacts'].includes(hash)) {
            switchPage(hash);
        } else {
            switchPage('home');
        }
    }
    
    window.addEventListener('hashchange', handleHash);
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', handleHash);
    } else {
        handleHash();
    }
})();